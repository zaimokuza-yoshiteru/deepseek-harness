# Atlassian 看板

面向 DSH `0.1.7-rc.2` 的 Jira、Bitbucket 和 Confluence Data Center 插件，支持 Web 与桌面客户端。查看已配置查询的结果，通过 `@` 将条目交给 AI，再由原生工具读取或修改对应内容。

目标版本：Jira `11.3.5`、Bitbucket `10.4.1`、Confluence `10.2.11`。`reference/atlassian-server-mcp` 仅用于参考接口与测试方式，插件不运行该 MCP。

## 构建和安装

使用 Node.js `^22.19.0 || >=24.0.0` 和 pnpm：

```sh
pnpm install --frozen-lockfile
pnpm typecheck
pnpm test
pnpm build
```

在这个目录执行本地安装，沿用启动 DSH 时的 `DSH_HOME`：

```sh
npx @deepseek-ai/dsh@0.1.7-rc.2 plugin --profile web add "$PWD"
```

桌面实例使用其实际 profile 安装同一个包。安装后的客户端需要刷新。当前版本为本地开发版本，未发布至 npm。

## 配置和使用

在「插件」中打开 Atlassian 看板的配置，分别填写各产品的 Base URL 和 Bearer Token。Base URL 可以包含实例路径前缀，例如 `https://intranet.example/jira`。

- Jira：添加名称和 JQL。
- Bitbucket：添加项目 Key 和仓库 Slug，显示名称为 `projectKey/repositorySlug`。
- Confluence：添加名称和 CQL。

每个列表都可以新增、修改和删除。已保存的 Token 不回显；留空保留原值，明确选择清除时才移除。

「@ 候选异步刷新」默认开启。关闭后，输入框只使用当前 DSH 实例已取得的查询缓存，不再自动请求 Atlassian；没有缓存时会显示提示。看板中的刷新按钮仍会请求服务器并更新缓存。修改连接或查询配置后，相关缓存会失效。

界面跟随 DSH「设置 → 语言」中的中文／English 选择。按钮、输入框、开关、设置字段和 Tab 优先使用 DSH 公开的原生组件，业务表格与卡片沿用 DSH 主题颜色。

侧栏「看板」位于「新会话」与「插件」之间。Jira 展示类型、Key、优先级、标题；Bitbucket 展示 PR ID 和标题，可切换全部、Open、Merged；Confluence 以两列卡片显示标题及查询结果元数据。点击条目在外部浏览器中打开原页面。切换查询时加载数据，也可手动刷新和加载后续结果。

在会话输入框键入 `@`，选择 jira、repo、pr 或 confluence，再选择配置的查询或仓库。候选来自这些配置范围，不做全站搜索。发给模型的引用只有定位信息：Jira key、仓库名称与 Git URL、带仓库身份的 PR ID、Confluence content ID。正文由 AI 在需要时调用工具读取。

## 工具与 ACP

插件注册 DSH 原生工具，提供 Jira 议题、评论、流转与字段元数据；Bitbucket 仓库和 PR 评审数据、评论、批准、需要修改及拒绝；Confluence 页面、评论和子页面操作。元数据仅支持查询，包含项目状态、custom field 定义与选项，不提供元数据管理操作。Atlassian 决定权限并记录审计。

元数据查询可以直接让 AI 执行，例如“列出项目 APP 的可用状态”“查 customfield_10001 的定义和在该项目中的选项”。字段定义与选项是独立查询；创建/编辑元数据和流转字段信息可以帮助 AI 确认必填项及允许值。

同一 DSH 实例安装 `dsh-acp-adapter` 时，适配器通过现有工具桥向当前 Agent 暴露这些工具，无需另填 MCP 配置。

## 让 AI 管理看板配置

插件也提供自身配置工具，修改会通过 DSH 原生设置服务持久化，重启后保留：

- `atlassian_get_settings`：读取配置和版本号，Token 只显示是否已配置。
- `atlassian_validate_repositories`：按项目 Key／仓库 Slug 批量校验尚未配置的仓库，使用已保存的 Bitbucket 连接。
- `atlassian_upsert_repositories` / `atlassian_delete_repositories`：批量新增、修改或删除仓库配置。
- `atlassian_upsert_queries` / `atlassian_delete_queries`：批量管理命名 JQL／CQL。
- `atlassian_update_connections` / `atlassian_set_preferences`：更新产品连接或候选刷新开关。

例如，复制一组仓库给 AI，并说：“先查询确认这 10 个仓库可以访问，再添加到看板，保留已有仓库。”AI 可以先读取配置、批量校验，再提交新增项。JQL／CQL 则可先使用已有查询工具验证表达式，再保存命名查询。

写工具使用 `expectedRevision` 检查配置版本。遇到并发修改，应重新读取配置再合并；配置页也会识别编辑期间的变更，避免旧草稿覆盖 AI 新增的条目。连接 Token 可更新或明确清除，不通过读取工具返回。

Jira 原生 Clone 使用 Jira 11.3.5 的内部 Web action，已验证简单议题克隆；附件、子任务、复杂自定义字段及异步任务仍需独立验证。它不属于 Jira 的公开 REST API。

所有 Atlassian 网络请求从 DSH 后端发送，并按此插件的内网使用要求关闭 HTTPS 证书校验。

## 发布内容

发布包仅包含运行代码、类型声明、插件补丁和使用说明；不包含源码映射、本地配置、测试数据或内部实施与验证记录。
