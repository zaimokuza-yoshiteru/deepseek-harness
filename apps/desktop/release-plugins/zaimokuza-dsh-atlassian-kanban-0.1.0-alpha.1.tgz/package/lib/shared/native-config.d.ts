import z from '@deepseek-ai/schemastery';
import type { Volatile } from '@deepseek-ai/cordis';
export interface Config {
    refreshMentions: Volatile<boolean>;
    jira: {
        baseUrl: Volatile<string>;
        bearerToken: Volatile<string>;
        jql: Volatile<{
            id: string;
            name: string;
            query: string;
        }[]>;
    };
    bitbucket: {
        baseUrl: Volatile<string>;
        bearerToken: Volatile<string>;
        repositories: Volatile<{
            id: string;
            projectKey: string;
            repositorySlug: string;
        }[]>;
    };
    confluence: {
        baseUrl: Volatile<string>;
        bearerToken: Volatile<string>;
        cql: Volatile<{
            id: string;
            name: string;
            query: string;
        }[]>;
    };
}
export declare const Config: ReturnType<typeof z.object>;
export type NativeConfig = Config;
