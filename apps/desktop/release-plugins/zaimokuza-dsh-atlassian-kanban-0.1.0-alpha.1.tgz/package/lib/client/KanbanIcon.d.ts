export declare function KanbanIcon(): import("react/jsx-runtime").JSX.Element;
