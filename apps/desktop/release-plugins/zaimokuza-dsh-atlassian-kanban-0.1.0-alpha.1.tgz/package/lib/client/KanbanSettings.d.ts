import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { NamedQuery, BitbucketRepositoryRef } from '../shared/config.ts';
import type { AtlassianKanbanRemote } from '../shared/remote.ts';
export interface ConfigValues {
    readonly refreshMentions: boolean;
    readonly jira: {
        readonly baseUrl: string;
        readonly jql: readonly NamedQuery[];
    };
    readonly bitbucket: {
        readonly baseUrl: string;
        readonly repositories: readonly BitbucketRepositoryRef[];
    };
    readonly confluence: {
        readonly baseUrl: string;
        readonly cql: readonly NamedQuery[];
    };
}
export interface KanbanConfigInjected {
    readonly form: ConfigForm<ConfigValues>;
    readonly remote: AtlassianKanbanRemote;
}
export type KanbanSettingsProps = PropsRuntime<'plugins.bundle.config'> & PropsLocale<'atlassianKanban'> & KanbanConfigInjected;
export declare function KanbanSettings(props: KanbanSettingsProps): import("react/jsx-runtime").JSX.Element;
