import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { AtlassianKanbanRemote } from '../shared/remote.ts';
import type { KanbanController } from './kanban-state.ts';
export interface KanbanPageInjected {
    readonly controller: KanbanController;
    readonly remote: AtlassianKanbanRemote;
    readonly openConfig: () => void;
}
export type KanbanPageProps = PropsRuntime<'main'> & PropsLocale<'atlassianKanban'> & KanbanPageInjected;
export declare function KanbanPage(props: KanbanPageProps): import("react/jsx-runtime").JSX.Element;
