import type { ConfigValues } from './KanbanSettings.tsx';
export type SettingsValidationKey = 'nameRequired' | 'queryRequired' | 'duplicateIds' | 'repositoryRequired' | 'duplicateRepositories';
/** Validate saved-scope identity before configuration writes can become ambiguous. */
export declare function validateSettings(values: ConfigValues): SettingsValidationKey | null;
