import type { SettingsPathOpView } from '@deepseek-ai/dsh-api-remotes/client';
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { AtlassianProduct } from '../shared/config.ts';
import type { ConfigValues } from './KanbanSettings.tsx';
export interface SecretDraft {
    readonly values: Readonly<Record<AtlassianProduct, string>>;
    readonly clear: Readonly<Record<AtlassianProduct, boolean>>;
}
/** Native settings operations are one atomic save and never read a stored token. */
export declare function buildSettingsOps(source: ConfigValues, secrets: SecretDraft): SettingsPathOpView[];
/** Fence a draft at the revision where its first edit was made. */
export declare function saveSettingsDraft(form: Pick<ConfigForm<ConfigValues>, 'mutate'>, ops: readonly SettingsPathOpView[], draftRevision: number | null, currentRevision: number | undefined): Promise<'saved' | 'conflict'>;
