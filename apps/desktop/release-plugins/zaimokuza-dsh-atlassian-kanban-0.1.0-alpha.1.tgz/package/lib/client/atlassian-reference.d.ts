import type { AtlassianKanbanRemote } from '../shared/remote.ts';
import type { InputTriggerSource } from '@deepseek-ai/dsh-client-ui-input-trigger/client';
/** The shared @ menu starts locally with four scopes; network reads wait for one explicit configured scope. */
export declare function createAtlassianReferenceSource(remote: AtlassianKanbanRemote, t: (key: string) => string): InputTriggerSource;
