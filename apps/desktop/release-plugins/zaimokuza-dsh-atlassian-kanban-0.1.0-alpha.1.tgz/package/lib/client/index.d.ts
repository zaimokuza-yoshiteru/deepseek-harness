import type { Context } from '@deepseek-ai/cordis';
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client';
export type * from '../shared/remote.ts';
export type * from '../shared/config.ts';
export declare const PANEL_ID: MainPanelId;
export declare const PACKAGE_NAME = "@zaimokuza/dsh-atlassian-kanban";
export declare const SETTINGS_NAMESPACE = "dsh-atlassian-kanban";
export declare const inject: string[];
/** Mount generated Remote methods before registering UI consumers that need them. */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
