import type { AtlassianSettingsView, NamedQuery } from '../shared/config.ts';
import type { AtlassianKanbanRemote, KanbanQueryResult } from '../shared/remote.ts';
export type KanbanView = 'jira' | 'bitbucket' | 'confluence';
export type PullRequestState = 'all' | 'open' | 'merged';
export type RequestStatus = 'idle' | 'loading' | 'ready' | 'error';
export interface KanbanSnapshot {
    readonly settings: AtlassianSettingsView | null;
    readonly product: KanbanView;
    readonly selection: string | null;
    readonly pullRequestState: PullRequestState;
    readonly status: RequestStatus;
    readonly result: KanbanQueryResult | null;
    readonly error: string | null;
    readonly loadingMore: boolean;
}
export declare const EMPTY_KANBAN_SNAPSHOT: KanbanSnapshot;
/** Owns the visible request generation so an old tab or page can never replace newer results. */
export declare class KanbanController {
    private readonly remote;
    private snapshot;
    private listeners;
    private request;
    private generation;
    private disposed;
    constructor(remote: AtlassianKanbanRemote);
    getSnapshot: () => KanbanSnapshot;
    subscribe: (listener: () => void) => (() => void);
    private publish;
    loadSettings(): Promise<void>;
    selectProduct(product: KanbanView): Promise<void>;
    selectQuery(selection: string): Promise<void>;
    setPullRequestState(pullRequestState: PullRequestState): Promise<void>;
    refresh(): Promise<void>;
    loadMore(): Promise<void>;
    dispose(): void;
    private run;
    private sameQuery;
    private queryFor;
    private firstSelection;
    private message;
}
export declare function namedQueries(settings: AtlassianSettingsView | null, product: 'jira' | 'confluence'): readonly NamedQuery[];
