import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { AtlassianProduct, AtlassianSettingsView } from '../shared/config.ts';
import type { ConnectionTestResult, KanbanQuery, KanbanQueryResult, KanbanSuggestionsResult } from '../shared/remote.ts';
import type { AtlassianService } from '../host/service.ts';
/** Renderer-facing, read-only surface. Model tools use the same host service. */
export declare class AtlassianKanbanRemote extends TypertRemoteService {
    private readonly service;
    constructor(ctx: Context, service: AtlassianService);
    settings(): AtlassianSettingsView;
    testConnection(product: AtlassianProduct): Promise<ConnectionTestResult>;
    query(input: KanbanQuery, signal: AbortSignal): Promise<KanbanQueryResult>;
    suggestions(input: KanbanQuery, signal: AbortSignal): Promise<KanbanSuggestionsResult>;
}
