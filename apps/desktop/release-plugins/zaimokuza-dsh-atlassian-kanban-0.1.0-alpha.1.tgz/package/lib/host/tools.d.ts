import type { Context } from '@deepseek-ai/cordis';
import type { AtlassianService } from './service.ts';
type Args = Record<string, any>;
export declare function registerTools(ctx: Context, service: AtlassianService): (() => void)[];
export declare function jiraNativeClone(service: AtlassianService, issueKey: string, args: Args, signal: AbortSignal): Promise<unknown>;
export declare function jiraGetCloneStatus(service: AtlassianService, taskId: string, requestedAction: string, signal: AbortSignal): Promise<unknown>;
export declare function jiraCustomFieldOptionsPath(fieldId: string): string;
export {};
