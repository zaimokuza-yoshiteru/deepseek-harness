import http from 'node:http';
import { URL } from 'node:url';
export interface AtlassianResponse<T> {
    readonly status: number;
    readonly headers: http.IncomingHttpHeaders;
    readonly data: T;
}
export declare class AtlassianHttpError extends Error {
    readonly status: number;
    readonly data: unknown;
    constructor(status: number, message: string, data: unknown);
}
/** Per-request Atlassian transport. TLS verification is disabled only on this HTTPS agent. */
export declare class AtlassianHttp {
    request<T>(baseUrl: string, token: string, method: string, apiPath: string, options?: {
        readonly query?: URLSearchParams;
        readonly body?: unknown;
        readonly form?: URLSearchParams;
        readonly headers?: http.OutgoingHttpHeaders;
        readonly signal?: AbortSignal;
        readonly accept?: string;
        readonly timeoutMs?: number;
        readonly maxResponseBytes?: number;
        readonly acceptedStatuses?: readonly number[];
    }): Promise<AtlassianResponse<T>>;
}
export declare function parseBaseUrl(input: string): URL;
