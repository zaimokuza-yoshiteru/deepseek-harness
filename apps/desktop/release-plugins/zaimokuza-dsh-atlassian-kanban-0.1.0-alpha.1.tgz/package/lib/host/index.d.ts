import type { Context } from '@deepseek-ai/cordis';
import type { Config as KanbanConfig } from '../shared/native-config.ts';
export declare const name = "dsh-atlassian-kanban";
export declare const inject: string[];
export declare function apply(ctx: Context, config: KanbanConfig): void;
