import type { Context } from '@deepseek-ai/cordis';
import type { SettingsPathOp } from '@deepseek-ai/dsh-settings';
import type { AtlassianKanbanConfig, AtlassianProduct, AtlassianSettingsView, BitbucketRepositoryCandidate, BitbucketRepositoryValidation } from '../shared/config.ts';
import type { ConnectionTestResult, KanbanQuery, KanbanQueryResult, KanbanSuggestionsResult } from '../shared/remote.ts';
import { AtlassianHttp } from './http.ts';
import type { AtlassianResponse } from './http.ts';
/** Host-owned REST operations used by the native Remote and model tools. */
export declare class AtlassianService {
    private readonly ctx;
    private readonly getConfig;
    readonly http: AtlassianHttp;
    private cacheFingerprint;
    private readonly resultCache;
    private readonly maxCacheEntries;
    private cacheGeneration;
    constructor(ctx: Context, getConfig: () => AtlassianKanbanConfig);
    settings(): AtlassianSettingsView;
    /** Direct read of host-only config; callers must never serialize its credentials. */
    configSnapshot(): AtlassianKanbanConfig;
    mutateSettings(expectedRevision: number, ops: readonly SettingsPathOp[], invalidateCache?: boolean): Promise<AtlassianSettingsView>;
    /** Mention-only lookup; when refresh is disabled this is a strictly local cache read. */
    suggestions(input: KanbanQuery, signal?: AbortSignal): Promise<KanbanSuggestionsResult>;
    /** Validate candidates with one exact repo GET each; never performs a repository search. */
    validateRepositories(candidates: readonly BitbucketRepositoryCandidate[], signal?: AbortSignal): Promise<BitbucketRepositoryValidation[]>;
    clearQueryCache(): void;
    /** Internal API helper for operations whose path is assembled by typed host code. */
    api<T>(product: AtlassianProduct, method: string, path: string, options?: Parameters<AtlassianHttp['request']>[4]): Promise<T>;
    nativeRequest(product: AtlassianProduct, method: string, path: string, options?: Parameters<AtlassianHttp['request']>[4]): Promise<AtlassianResponse<unknown>>;
    testConnection(product: AtlassianProduct): Promise<ConnectionTestResult>;
    query(input: KanbanQuery, signal?: AbortSignal): Promise<KanbanQueryResult>;
    private queryUncached;
    private cacheKey;
    private fingerprint;
    private syncCacheFingerprint;
    searchJira(jql: string, cursor?: string, maxResults?: number, signal?: AbortSignal): Promise<KanbanQueryResult>;
    repositoryByIdentity(projectKey: string, repositorySlug: string, signal?: AbortSignal): Promise<KanbanQueryResult>;
    pullRequestsByIdentity(projectKey: string, repositorySlug: string, state: 'all' | 'open' | 'merged', cursor?: string, limit?: number, signal?: AbortSignal): Promise<KanbanQueryResult>;
    searchConfluence(cql: string, cursor?: string, limit?: number, signal?: AbortSignal): Promise<KanbanQueryResult>;
    private config;
    private call;
    private safeError;
    private jiraIssue;
    private jiraSearch;
    private jiraSearchExpression;
    private repository;
    private pullRequest;
    private prView;
    private pullRequests;
    private confluencePage;
    private pageView;
    private confluenceSearch;
    private confluenceSearchExpression;
    private absolute;
}
